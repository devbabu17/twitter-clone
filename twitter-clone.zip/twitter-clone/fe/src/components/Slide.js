import React from 'react'
import {Link} from 'react-router-dom';
import { useDispatch } from 'react-redux';
// import { useSelector } from 'react-redux'
import './Slide.css'
const Slide = () => {

  const dispatch=useDispatch()

  // const user=useSelector(state=>state.userReducer)
  // console.log(user)
    const logout=()=>{
      localStorage.removeItem("token");
      localStorage.removeItem("user")
      dispatch({type:"LOGIN_ERROR"})
    }

  return (
    <div className='col-3 slider'>
    <div className='b1'>
    
          <div className="btn-group-vertical links-group" role="group" >
          <div className='brand ms-2 mt-2'><i class="fa-brands fa-twitter"></i></div>
            <Link to="/home" className="btn "  ><i class="fa-solid fa-house"></i><span>Home</span></Link>
            <Link to="/profile" className="btn "  ><i class="fa-solid fa-user"></i><span>Profile</span></Link>
            <Link to="/login" className="btn ms-1" onClick={()=>logout()}><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></Link>
          </div>
    </div>
    <div className='mb-2'>
    <div>
      <h6 className='text-success' style={{"text-align":"center"}}>Copyright @ Dev Nishant</h6>
      </div>
    </div>
  </div>
)
}

export default Slide;